package BlackJack;

//һ��ֽ��
public class Card {
	public static final String[] FACES = {"A","2","3","4","5","6","7","8","9","10","J","Q","K"};
	public static final String[] SUITS = {"heart", "spade", "diamond", "club"};
	private int point;
	private boolean isAvailable;
	private String face;
	private String suit;
	
	//�޲ι��캯��
	public Card() {
		point = 0;
		face = "";
		suit = "";
		isAvailable = true;
	}
	
	//�в������캯��, һ���ƣ�ֵ��1-52֮�����Ч
	public Card(int n) {
		isAvailable = true;
		if(n <= 52 && n > 0) {
			face = FACES[n % FACES.length];
			suit = SUITS[n % SUITS.length];
			switch(face) {
			case "A": point = 11; break;
			case "2": point = 2; break;
			case "3": point = 3; break;
			case "4": point = 4; break;
			case "5": point = 5; break;
			case "6": point = 6; break;
			case "7": point = 7; break;
			case "8": point = 8; break;
			case "9": point = 9; break;
			default: point = 10;
			}
		}
		else {
			System.out.println("Wrong index, program exit!");
			System.exit(0);
		}
	}
	
	//�õ�һ��ֽ���Ƿ񱻷��ʵ�״̬
	public boolean getIsAvailable() {
		return isAvailable;
	}
	
	//����ֽ�Ƶķ���״̬
	public void setIsAvailable(boolean isAvailable) {
		this.isAvailable = isAvailable;
	}
	
	//�õ�ֽ�ƵĻ�ɫ
	public String getSuit() {
		return suit;
	}
	
	//�õ�ֽ�Ƶ���ֵ
	public String getFace() {
		return face;
	}
	
	//�õ�ֽ�ƴ����ĵ���
	public int getPoint() {
		return point;
	}
	
	
}
